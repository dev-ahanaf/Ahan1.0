# Security model: reference demo vs. production

**LAN-only demo:** FastAPI listens on local network HTTP. Browser HTTP Basic credentials, device tokens, enrollment key and voice recordings are transmitted unencrypted. Attackers on the path can intercept them. Use a trusted, isolated private network. **Do not forward TCP/8000** to the internet, deploy this unmodified on a public host, or treat the demo as a secure consumer product.

**Production requirements:**

1. Replace shared `ENROLLMENT_KEY` with a **unique factory-issued identity/credential for each ESP32**, inject through a secure manufacturing/setup path, and store/validate only hashed tokens on server. Avoid a common key shared by all production units.
2. Use HTTPS/WSS with certificate verification and key rotation. On constrained hardware, consider pinned public keys or a maintained trust store, not `setInsecure()`.
3. Replace admin HTTP Basic with account auth + salted password hashes, MFA or session tokens, CSRF protection and rate limits, plus device-owner authorization on every operation.
4. Bind short-lived pairing approval to a particular pending device identity; add attempt throttling, rotation and operator/audit trails.
5. Provide authenticated token-revoke, re-enrollment and device factory-reset flows. Protect NVS credentials with flash encryption/secure boot where supported.
6. For remote controls, define explicit device capability allowlists and authenticated command envelopes. Don't execute LLM text as arbitrary firmware commands.
7. Control voice data retention, consent, provider disclosure, child/guest access and API expenditure. The demo currently sends audio to an external speech provider when enabled.
8. Add binary signing and authenticity checks before OTA.

`PROVISIONING_AP_PASSWORD` is configurable; the demo SoftAP uses WPA2 (when hardware supports it) and is not a replacement for secure provisioning. On first setup, Wi-Fi credentials are entered through a local portal (which is not HTTPS).
