// MyVoice OS v0.1 — original regular ESP32 (ESP32-WROOM-32 / DevKit).
// PINOUT in README. LAN-only reference: plain HTTP is NOT production-secure.
// Arduino core 2.0.17 (PlatformIO espressif32 6.12.0), legacy driver/i2s.h.
#include <Arduino.h>
#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <LittleFS.h>
#include <Preferences.h>
#include <WiFi.h>
#include <WiFiManager.h>
#include <driver/i2s.h>
#include <time.h>
#include "secrets.h"

static constexpr int BUTTON_PIN=27;            // Push-to-talk: GPIO27 to GND
static constexpr int MIC_BCLK=26;              // INMP441 SCK
static constexpr int MIC_WS=25;                // INMP441 WS
static constexpr int MIC_DATA=33;              // INMP441 SD
static constexpr int SPK_BCLK=14;              // MAX98357A BCLK
static constexpr int SPK_WS=13;                // MAX98357A LRC
static constexpr int SPK_DATA=22;              // MAX98357A DIN
static constexpr int RECORD_HZ=16000;
static constexpr int RECORD_SECONDS=3;
static constexpr size_t RECORD_SAMPLES=RECORD_HZ * RECORD_SECONDS;
static constexpr unsigned long POLL_MS=5000;
static constexpr unsigned long HEARTBEAT_MS=30000;
static constexpr unsigned long WEATHER_MS=5UL*60UL*1000UL;

Preferences prefs;
String deviceId, deviceToken, pairCode;
bool paired=false, i2sReady=false;
unsigned long lastPoll=0, lastHeartbeat=0, lastWeather=0, lastClock=0;

String apiUrl(const char *path) { return String(API_BASE_URL) + path; }

void authHeaders(HTTPClient &http) {
  http.addHeader("X-Device-ID", deviceId);
  http.addHeader("X-Device-Token", deviceToken);
}

bool parseJson(const String &body, DynamicJsonDocument &doc) {
  DeserializationError err=deserializeJson(doc, body);
  if (err) { Serial.printf("JSON parse error: %s\n",err.c_str());return false; }
  return true;
}

void showCode(const String &code) {
  Serial.println("\n=========================================");
  Serial.printf("  MYVOICE PAIRING CODE: %s\n",code.c_str());
  Serial.println("  Enter at http://YOUR-SERVER-IP:8000");
  Serial.println("  Code expires after 10 minutes.");
  Serial.println("=========================================\n");
  // Add OLED display rendering here in a board-specific extension.
}

// First boot obtains a device credential and a 10-minute pairing code.
void bootstrap() {
  if (deviceToken.length()) return;
  HTTPClient http;
  http.begin(apiUrl("/api/device/bootstrap"));
  http.setTimeout(10000);
  http.addHeader("Content-Type","application/json");
  http.addHeader("X-Enrollment-Key", ENROLLMENT_KEY);
  DynamicJsonDocument request(256);
  request["device_id"]=deviceId;
  request["firmware"]=DEVICE_FW_VERSION;
  String payload; serializeJson(request,payload);
  int code=http.POST(payload);
  String body=http.getString();http.end();
  if(code!=200) {Serial.printf("Bootstrap failed HTTP %d: %s\n",code,body.c_str());return;}
  DynamicJsonDocument doc(512);
  if(!parseJson(body,doc)) return;
  deviceToken=doc["token"].as<String>();
  pairCode=doc["pair_code"].as<String>();
  if (!deviceToken.length()) return;
  prefs.putString("token",deviceToken);
  prefs.putString("paircode",pairCode);
  showCode(pairCode);
}

void pollStatus() {
  if(!deviceToken.length()) return;
  HTTPClient http;
  http.begin(apiUrl("/api/device/status"));
  http.setTimeout(10000);
  authHeaders(http);
  int status=http.GET();
  String body=http.getString();http.end();
  if(status==401) {Serial.println("Device token rejected; contact admin to reset enrollment.");return;}
  if(status!=200) {Serial.printf("Status error %d\n",status);return;}
  DynamicJsonDocument doc(512);
  if(!parseJson(body,doc)) return;
  paired=doc["paired"].as<bool>();
  String renewed=doc["pair_code"].as<String>();
  if(renewed.length()) {
    pairCode=renewed;
    prefs.putString("paircode",pairCode);
    showCode(pairCode);
  }
  if(paired) {
    if(pairCode.length()) Serial.println("Device paired successfully! Press GPIO27 button for 3s voice capture.");
    pairCode="";
    prefs.remove("paircode");
  }
}

void heartbeat() {
  if(!paired) return;
  HTTPClient http;
  http.begin(apiUrl("/api/device/heartbeat"));http.setTimeout(7000);
  authHeaders(http);
  http.addHeader("Content-Type","application/json");
  int status=http.POST("{}");
  Serial.printf("Heartbeat: %d\n",status);
  http.end();
  if(status==403 || status==401) paired=false;
}

void pollWeather() {
  if(!paired) return;
  HTTPClient http;
  http.begin(apiUrl("/api/device/weather"));http.setTimeout(14000);
  authHeaders(http);
  int status=http.GET();
  String body=http.getString();http.end();
  if(status!=200) {Serial.printf("Weather service HTTP %d\n",status);return;}
  DynamicJsonDocument doc(512);
  if(!parseJson(body,doc)) return;
  Serial.printf("Weather in %s: %.1f C, %s, wind %.1f km/h\n",
                doc["city"].as<const char *>(),doc["temperature_c"].as<float>(),
                doc["conditions"].as<const char *>(),doc["wind_kmh"].as<float>());
}

// Minimal canonical RIFF/WAV header, PCM mono 16-bit 16 kHz.
void writeLE16(File &file,uint16_t v){file.write((uint8_t)(v&255));file.write((uint8_t)(v>>8));}
void writeLE32(File &file,uint32_t v){for(int i=0;i<4;i++) file.write((uint8_t)(v>>(i*8)));}
void writeWavHeader(File &file,uint32_t dataSize) {
  file.write((const uint8_t*)"RIFF",4);writeLE32(file,dataSize+36);
  file.write((const uint8_t*)"WAVEfmt ",8);writeLE32(file,16);
  writeLE16(file,1);writeLE16(file,1);writeLE32(file,RECORD_HZ);
  writeLE32(file,RECORD_HZ*2);writeLE16(file,2);writeLE16(file,16);
  file.write((const uint8_t*)"data",4);writeLE32(file,dataSize);
}

bool setupI2s() {
  // Two independent I2S peripherals: one receiver and one transmitter.
  i2s_config_t mic={};
  mic.mode=(i2s_mode_t)(I2S_MODE_MASTER|I2S_MODE_RX);
  mic.sample_rate=RECORD_HZ;
  mic.bits_per_sample=I2S_BITS_PER_SAMPLE_32BIT;
  mic.channel_format=I2S_CHANNEL_FMT_ONLY_LEFT; // INMP441 L/R pin GND
  mic.communication_format=I2S_COMM_FORMAT_STAND_I2S;
  mic.intr_alloc_flags=ESP_INTR_FLAG_LEVEL1;
  mic.dma_buf_count=4;mic.dma_buf_len=256;
  mic.use_apll=false;
  i2s_pin_config_t micPins={};
  micPins.bck_io_num=MIC_BCLK;
  micPins.ws_io_num=MIC_WS;
  micPins.data_out_num=I2S_PIN_NO_CHANGE;
  micPins.data_in_num=MIC_DATA;
  if(i2s_driver_install(I2S_NUM_0,&mic,0,nullptr)!=ESP_OK) return false;
  if(i2s_set_pin(I2S_NUM_0,&micPins)!=ESP_OK) return false;

  i2s_config_t speaker={};
  speaker.mode=(i2s_mode_t)(I2S_MODE_MASTER|I2S_MODE_TX);
  speaker.sample_rate=24000;
  speaker.bits_per_sample=I2S_BITS_PER_SAMPLE_16BIT;
  speaker.channel_format=I2S_CHANNEL_FMT_ONLY_LEFT;
  speaker.communication_format=I2S_COMM_FORMAT_STAND_I2S;
  speaker.intr_alloc_flags=ESP_INTR_FLAG_LEVEL1;
  speaker.dma_buf_count=6;speaker.dma_buf_len=256;
  speaker.use_apll=false;
  speaker.tx_desc_auto_clear=true;
  i2s_pin_config_t speakerPins={};
  speakerPins.bck_io_num=SPK_BCLK;
  speakerPins.ws_io_num=SPK_WS;
  speakerPins.data_out_num=SPK_DATA;
  speakerPins.data_in_num=I2S_PIN_NO_CHANGE;
  if(i2s_driver_install(I2S_NUM_1,&speaker,0,nullptr)!=ESP_OK) return false;
  if(i2s_set_pin(I2S_NUM_1,&speakerPins)!=ESP_OK) return false;
  return true;
}

bool recordWav() {
  File f=LittleFS.open("/voice.wav","w");
  if(!f) {Serial.println("Cannot create /voice.wav");return false;}
  writeWavHeader(f,RECORD_SAMPLES*2);
  static int32_t incoming[256];
  static int16_t samples[256];
  size_t written=0;
  Serial.println("Recording 3 seconds... Speak now!");
  while(written<RECORD_SAMPLES) {
    size_t bytesRead=0;
    if(i2s_read(I2S_NUM_0,incoming,sizeof(incoming),&bytesRead,pdMS_TO_TICKS(1500))!=ESP_OK || bytesRead==0) {
      f.close();LittleFS.remove("/voice.wav");Serial.println("Mic timeout");return false;
    }
    size_t count=min(bytesRead/sizeof(int32_t),RECORD_SAMPLES-written);
    for(size_t i=0;i<count;i++) {
      // INMP441 left channel data is typically left-aligned 24-bit in a 32-bit slot.
      // Tune shift/gain on your board if samples are too quiet or clipped.
      int32_t s=incoming[i]>>14;
      if(s>32767)s=32767;if(s< -32768)s=-32768;
      samples[i]=(int16_t)s;
    }
    if(f.write((const uint8_t*)samples,count*2)!=count*2) {
      f.close();LittleFS.remove("/voice.wav");Serial.println("Flash write failure");return false;
    }
    written+=count;
  }
  f.close();
  Serial.printf("WAV saved: %u samples\n",(unsigned)written);
  return true;
}

uint16_t little16(const uint8_t *p) {return (uint16_t)p[0]|((uint16_t)p[1]<<8);}
uint32_t little32(const uint8_t *p) {return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}

// Skip metadata chunks until a standard uncompressed 16-bit MONO PCM data chunk.
// Do not stream MP3 into I2S as raw audio; server must return audio/wav.
bool playWavStream(WiFiClient &stream) {
  stream.setTimeout(12000);
  uint8_t header[12];
  if(stream.readBytes((char*)header,12)!=12 || memcmp(header,"RIFF",4)!=0 || memcmp(header+8,"WAVE",4)!=0) {
    Serial.println("Audio reply is not RIFF/WAVE");return false;
  }
  uint16_t audioFormat=0,channels=0,depth=0;uint32_t hz=0;
  bool fmtFound=false;uint32_t dataLeft=0;
  for(int part=0;part<16;part++) {
    uint8_t chunk[8];if(stream.readBytes((char*)chunk,8)!=8)return false;
    uint32_t length=little32(chunk+4);
    if(memcmp(chunk,"fmt ",4)==0) {
      if(length<16||length>128)return false;
      uint8_t fmt[128];if(stream.readBytes((char*)fmt,length)!=length)return false;
      audioFormat=little16(fmt);channels=little16(fmt+2);
      hz=little32(fmt+4);depth=little16(fmt+14);fmtFound=true;
    } else if(memcmp(chunk,"data",4)==0) {
      dataLeft=length;break;
    } else {
      if(length>500000) return false;
      uint8_t drop[128];
      uint32_t remaining=length;
      while(remaining) {size_t n=min((uint32_t)sizeof(drop),remaining);
        if(stream.readBytes((char*)drop,n)!=n)return false;remaining-=n;}
    }
    if((length&1) && stream.readBytes((char*)header,1)!=1)return false;
  }
  if(!fmtFound || audioFormat!=1 || channels!=1 || depth!=16 || hz<8000 || hz>48000 || dataLeft>3000000 || dataLeft==0) {
    Serial.printf("Unsupported voice WAV: format=%u channels=%u bits=%u Hz=%lu bytes=%lu\n",
                  audioFormat,channels,depth,(unsigned long)hz,(unsigned long)dataLeft);
    return false;
  }
  i2s_set_clk(I2S_NUM_1,hz,I2S_BITS_PER_SAMPLE_16BIT,I2S_CHANNEL_MONO);
  Serial.printf("Playing reply: %lu Hz, %lu bytes\n",(unsigned long)hz,(unsigned long)dataLeft);
  uint8_t data[1024];
  while(dataLeft>0) {
    size_t desired=min((uint32_t)sizeof(data),dataLeft);
    size_t n=stream.readBytes((char*)data,desired);
    if(n==0) {Serial.println("Speaker stream timed out");return false;}
    size_t w=0;
    if(i2s_write(I2S_NUM_1,data,n,&w,pdMS_TO_TICKS(1500))!=ESP_OK || w!=n)return false;
    dataLeft-=n;
  }
  i2s_zero_dma_buffer(I2S_NUM_1);
  return true;
}

void sendVoice() {
  if(!paired) {Serial.println("Pair device first");return;}
  if(!recordWav()) return;
  File f=LittleFS.open("/voice.wav","r");
  if(!f)return;
  HTTPClient http;
  http.begin(apiUrl("/api/device/voice"));
  http.setTimeout(75000);
  authHeaders(http);
  http.addHeader("Content-Type","audio/wav");
  // Stream from flash: avoid allocating entire recording in 520-KB classic ESP32 RAM.
  int status=http.sendRequest("POST",&f,f.size());
  f.close();LittleFS.remove("/voice.wav");
  if(status!=200) {Serial.printf("Voice HTTP %d: %s\n",status,http.getString().c_str());http.end();return;}
  bool ok=playWavStream(*http.getStreamPtr());
  Serial.println(ok?"Voice playback complete":"Voice playback failed");
  http.end();
}

void setup() {
  Serial.begin(115200);delay(700);
  pinMode(BUTTON_PIN,INPUT_PULLUP);
  deviceId=WiFi.macAddress(); // WiFi stack initialized below; updated after connection.
  prefs.begin("myvoice",false);
  deviceToken=prefs.getString("token","");
  pairCode=prefs.getString("paircode","");
  WiFi.mode(WIFI_STA);
  WiFiManager manager;
  manager.setConfigPortalTimeout(180);
  if(!manager.autoConnect("MyVoice-Setup",PROVISIONING_AP_PASSWORD)) {
    Serial.println("Provisioning timed out. Reboot to retry.");delay(3000);ESP.restart();
  }
  deviceId=WiFi.macAddress();
  Serial.printf("Connected: %s, device=%s\n",WiFi.localIP().toString().c_str(),deviceId.c_str());
  configTime(GMT_OFFSET_SEC,0,"pool.ntp.org","time.google.com");
  if(!LittleFS.begin(true))Serial.println("LittleFS mount failed");
  i2sReady=setupI2s();
  Serial.println(i2sReady?"I2S ready":"I2S initialization failed");
  bootstrap();
  if(pairCode.length())showCode(pairCode);
  pollStatus();
}

void loop() {
  if(WiFi.status()!=WL_CONNECTED) {
    paired=false;
    Serial.println("Wi-Fi lost, reconnecting...");WiFi.reconnect();delay(2000);return;
  }
  unsigned long ms=millis();
  if(!deviceToken.length() && ms-lastPoll>POLL_MS)bootstrap();
  if(ms-lastPoll>POLL_MS) {
    lastPoll=ms;
    if(!paired) pollStatus();
  }
  if(paired && ms-lastHeartbeat>HEARTBEAT_MS){lastHeartbeat=ms;heartbeat();}
  if(paired && ms-lastWeather>WEATHER_MS){lastWeather=ms;pollWeather();}
  if(ms-lastClock>60000UL) {
    lastClock=ms;
    struct tm localClock;
    if(getLocalTime(&localClock,10)) {
      Serial.printf("ESP32 clock (firmware timezone): %04d-%02d-%02d %02d:%02d:%02d\n",
        localClock.tm_year+1900,localClock.tm_mon+1,localClock.tm_mday,
        localClock.tm_hour,localClock.tm_min,localClock.tm_sec);
    }
  }
  if(paired && i2sReady && digitalRead(BUTTON_PIN)==LOW) {
    delay(35);
    if(digitalRead(BUTTON_PIN)==LOW) {
      sendVoice();
      while(digitalRead(BUTTON_PIN)==LOW)delay(10);
      delay(150);
    }
  }
  delay(20);
}
