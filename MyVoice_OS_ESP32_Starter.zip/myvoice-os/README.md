# MyVoice OS — regular ESP32 starter (v0.1)

A **new, custom-branded** XiaoZhi-inspired voice-assistant stack. It does not require the XiaoZhi app or backend.

**What is implemented here**: ESP32 Wi-Fi captive-portal setup; device bootstrap, expiring 6-digit pairing code, persistent device token, admin web dashboard, per-device name/location/timezone, authenticated heartbeats, NTP clock, weather via Open-Meteo, text-based assistant commands, and a *push-to-talk* I2S audio prototype. When a compatible cloud speech key is present, the device records 3 seconds of speech, sends a WAV file, transcribes, answers, receives a WAV file, and plays it through an I2S speaker.

**NOT implemented**: always-listening wake-word, offline transcription, generic real-time WebSocket streaming, Android/iOS app, OLED display, OTA, alarms, general home automation, strong production-grade provisioning, multiuser permissions or HTTPS on ESP32. An API key is needed for cloud voice and LLM. A Brave Search API key is needed for general live web search.

> Safety: server and firmware are configured for **trusted LAN-only development with HTTP**. Basic Auth, the enrollment key, and device tokens are visible to anyone who can intercept the HTTP traffic. Never port-forward the demo. See [docs/SECURITY.md](docs/SECURITY.md).

## 1. Architecture

```text
Browser / Dashboard (FastAPI-served HTML + JS)
         | Basic Auth (local lab)
         v
FastAPI backend --------------------------------> SQLite device registry
  |          |           |                |
  |          |           |                +-> Open-Meteo weather API
  |          |           +-------------------> Brave Search API (optional)
  |          +-------------------------------> Chat model API (optional)
  +------------------------------------------> Speech-to-text / TTS (optional)
         ^
         | device token + enrollment / pair protocol; HTTP on LAN
         v
ESP32-WROOM-32 + push button + INMP441 I2S mic + MAX98357A amp
                    |
                Speaker (4 or 8 ohm)
```

The firmware and backend use **POST WAV -> receive WAV** for MVP voice, not duplex conversation or WebSockets. This trades response latency for much simpler debugging on a regular ESP32 without PSRAM. Audio is stored only temporarily on the device (`LittleFS`) and is not stored by this server.

## 2. Hardware wiring

Use a regular **ESP32 DevKit V1 / ESP32-WROOM-32** (not ESP8266). You also need an INMP441 I2S microphone, MAX98357A I2S amplifier, 4-8 ohm small speaker and one momentary push button.

| Part | Pin on part | ESP32 DevKit pin |
|---|---|---|
| INMP441 | VDD | 3V3 **only** |
| INMP441 | GND | GND |
| INMP441 | SCK / BCLK | GPIO 26 |
| INMP441 | WS / LRCL | GPIO 25 |
| INMP441 | SD / DOUT | GPIO 33 |
| INMP441 | L/R | GND (left channel) |
| MAX98357A | VIN | 5V/VIN supply compatible with your board/amp |
| MAX98357A | GND | Common GND |
| MAX98357A | BCLK | GPIO 14 |
| MAX98357A | LRC / WS | GPIO 13 |
| MAX98357A | DIN | GPIO 22 |
| Speaker | + / - | Amp speaker terminals, **not** ESP32 GND |
| Push button | one contact | GPIO 27 |
| Push button | other contact | GND |

Check your amplifier module's VIN/SD pin requirements. Use common ground. Some USB ports cannot drive a loud speaker; start at low power. The software uses separate I2S controllers: RX on I2S0 and TX on I2S1. **Never put 5 V on ESP32 GPIO or the INMP441 VDD.**

## 3. Start server (Windows PowerShell, macOS or Linux)

Prereqs: Python 3.11+ and VS Code with PlatformIO extension.

In the `server` folder:

```bash
python -m venv .venv
```

Activate:

```bash
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell instead:
# .venv\Scripts\Activate.ps1
```

Install and configure:

```bash
python -m pip install -r requirements.txt
cp .env.example .env
```

On Windows PowerShell, replace `cp` with `Copy-Item .env.example .env` if necessary. Open `.env` and set **strong, unique** ADMIN_PASSWORD and ENROLLMENT_KEY. Both are required. You can generate random values:

```bash
python -c "import secrets;print(secrets.token_urlsafe(36))"
```

Run:

```bash
python -m uvicorn app:app --host 0.0.0.0 --port 8000 --reload
```

Find your computer's **LAN IP** using `ipconfig` (Windows) or `ipconfig getifaddr en0` / system network settings (macOS). Open `http://YOUR-LAN-IP:8000` on the **same trusted network**. The browser will ask for Basic Auth. Username is `admin`, password is the value in `.env`.

Before flashing, test `http://127.0.0.1:8000/api/health` on the host. If another device cannot reach the LAN IP, inspect firewall and network client-isolation settings. Do not make the backend public to fix this.

## 4. Flash ESP32 firmware

1. Open `firmware/` in VS Code with the **PlatformIO** extension installed.
2. Copy `firmware/include/secrets.h.example` to `firmware/include/secrets.h`.
3. Set `API_BASE_URL` to `http://YOUR-LAN-IP:8000` (**not localhost**).
4. Copy `ENROLLMENT_KEY` **exactly** from server `.env` into `secrets.h`.
5. Replace `PROVISIONING_AP_PASSWORD` with your own 8+ character password.
6. Connect ESP32 to USB and use **PlatformIO: Upload**. Set/select the COM/serial port if required.
7. Start **PlatformIO: Serial Monitor** at **115200**.
8. On a first boot it creates temporary Wi-Fi `MyVoice-Setup`; join with the provisioning password. A captive portal should open. If it doesn't, browse `192.168.4.1`, select your 2.4 GHz Wi-Fi SSID and enter password. Your PC/server and ESP32 must reach each other across the LAN.
9. ESP32 prints `MYVOICE PAIRING CODE: ######`; open the dashboard, enter that code and choose a name.
10. After pairing, ESP32 sends heartbeat data and prints weather. Press the GPIO27 button to record a **fixed 3 seconds** and play the spoken reply (requires cloud speech API key).

The `secrets.h` file, `.env`, the database and build files are excluded from Git via `.gitignore`. `ESP32` stores Wi-Fi settings via WiFiManager and the device token via `Preferences` NVS; do not share raw flash images.

### Pairing state machine

```text
UNPROVISIONED --Wi-Fi setup--> CONNECTED
CONNECTED --bootstrap with enrollment key--> PENDING (10-minute code)
PENDING --admin claims code--> PAIRED
PAIRED --heartbeat + weather + optional voice--> ACTIVE
PENDING --code expires--> automatic rotation on authenticated status poll
PAIRED --device token lost--> manual admin recovery required in this version
```

#### API overview

| Endpoint | Authentication | Use |
|---|---|---|
| `GET /` | HTTP Basic | Dashboard |
| `GET /api/health` | None | Local server health |
| `POST /api/device/bootstrap` | `X-Enrollment-Key` | Issue device token + pairing code |
| `GET /api/device/status` | Device ID + token | Pair status / rotate expired code |
| `POST /api/admin/claim` | HTTP Basic | Claim device by 6-digit code |
| `GET /api/admin/devices` | HTTP Basic | Device list |
| `POST /api/admin/devices/{id}/settings` | HTTP Basic | Device profile |
| `POST /api/device/heartbeat` | Device ID + token | Keepalive |
| `GET /api/device/weather` | Device ID + token | Weather data |
| `GET /api/device/time` | Device ID + token | Local time ISO-8601 |
| `POST /api/admin/ask` | HTTP Basic | Text command / dashboard demo |
| `POST /api/device/voice` | Device ID + token | Upload RIFF PCM WAV, return audio/wav |

## 5. Voice and live web search (optional)

Set `OPENAI_API_KEY` in `server/.env`, restart FastAPI. The audio flow uses a hosted transcription model (`gpt-4o-mini-transcribe`), short text response, and WAV speech synthesis (`tts-1`). The server uses `AI_MODEL` for general knowledge replies. Cloud API access is billable and may require account setup. Never put the API key on the ESP32.

Set `BRAVE_SEARCH_API_KEY` to enable requests such as "Search for Mars rover news". Search uses Brave's web search results (not a general browser). Without the key, search returns a setup reminder. Open-Meteo time/weather and device pairing don't need either key, subject to provider usage terms.

**Language**: Unicode Bangla text is accepted by the backend. The selected cloud STT/TTS voices may not sound natural in Bangla; validate with your own sample recordings, or replace the providers with appropriate Bangla-capable services. The firmware audio shift is a hardware-dependent starting point; test audibility and clipping before tuning gain.

## 6. Local tests

```bash
cd server
python -m pytest -q
```

Backend automated tests exercise credential boundaries, pairing, heartbeat, settings, time command and absent voice key. Weather, cloud voice, and real hardware need live/manual integration testing.

## 7. Roadmap

- **v0.1**: LAN server + secure-ish lab pairing + audio push-to-talk proof of concept (**this repo**).
- **v0.2**: HTTPS with ESP32 certificate validation, unique per-device pre-provisioned credentials, remote revoke/re-enroll, pairing audit logs, optional OLED status.
- **v0.3**: streaming Opus over WebSocket, wake-word with carefully evaluated ESP32 memory usage, cancellation / interruption.
- **v0.4**: MQTT, GPIO control allowlists, alarm/timer persistence, signed OTA, role-based multiuser accounts.
- **v1.0**: mobile onboarding, fleet management, scalable database, observability, deployment hardening.

## 8. Known tradeoffs

- An ESP32 without PSRAM is memory-tight; flash buffering of 3-second WAV avoids keeping raw audio in RAM. Voice latency is **not realtime**.
- Firmware is pinned to Arduino-ESP32 `2.0.17` through `espressif32@6.12.0` for legacy `driver/i2s.h` compatibility. Porting to Arduino 3.x requires changes.
- HTTP LAN demo is **not secure outside a private, trusted test network**. Pair codes mitigate accidental assignment but the global enrollment key is not a factory identity.
- No physical ESP32 was connected when generating the starter; hardware compile, microphone polarity/gain and speaker format must be checked on the exact modules.
- Weather location is saved as city label plus latitude and longitude; changing only the city name does **not** geocode the city. Change coordinates too.

See also [docs/SECURITY.md](docs/SECURITY.md) and [docs/NEXT_STEPS.md](docs/NEXT_STEPS.md).
