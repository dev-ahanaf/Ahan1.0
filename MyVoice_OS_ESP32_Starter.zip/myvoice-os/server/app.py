"""MyVoice OS reference backend. Development LAN only; read SECURITY.md before deployment."""
from __future__ import annotations

import hashlib
import os
import re
import secrets
import sqlite3
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

import httpx
from dotenv import load_dotenv
from fastapi import Depends, FastAPI, Header, HTTPException, Request, Response, status
from fastapi.responses import FileResponse, JSONResponse
from fastapi.security import HTTPBasic, HTTPBasicCredentials
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parent
load_dotenv(ROOT / ".env")
ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "")
ENROLLMENT_KEY = os.getenv("ENROLLMENT_KEY", "")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY", "")
BRAVE_SEARCH_API_KEY = os.getenv("BRAVE_SEARCH_API_KEY", "")
AI_MODEL = os.getenv("AI_MODEL", "gpt-4.1-mini")
DATABASE_PATH = os.getenv("DATABASE_PATH", str(ROOT / "myvoice.db"))
if not Path(DATABASE_PATH).is_absolute():
    DATABASE_PATH = str((ROOT / DATABASE_PATH).resolve())

# Avoid accidentally running with example credentials in a real network.
if (len(ADMIN_PASSWORD) < 16 or ADMIN_PASSWORD.startswith("replace-") or
        len(ENROLLMENT_KEY) < 24 or ENROLLMENT_KEY.startswith("replace-")):
    raise RuntimeError("Configure unique ADMIN_PASSWORD (>=16 chars) and ENROLLMENT_KEY (>=24 chars) in server/.env")

app = FastAPI(title="MyVoice OS", version="0.1.0")
security = HTTPBasic()
MAX_WAV_BYTES = 192_000
PAIR_DURATION = timedelta(minutes=10)


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def digest(v: str) -> str:
    return hashlib.sha256(v.encode()).hexdigest()


def code_digest(code: str) -> str:
    return digest(ENROLLMENT_KEY + ":" + code)


@contextmanager
def db():
    conn = sqlite3.connect(DATABASE_PATH, timeout=10)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
        conn.commit()
    finally:
        conn.close()


def init_db():
    Path(DATABASE_PATH).parent.mkdir(parents=True, exist_ok=True)
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS devices (
            id TEXT PRIMARY KEY, name TEXT NOT NULL, token_hash TEXT NOT NULL,
            pair_hash TEXT, pair_expires TEXT, paired INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL, last_seen TEXT, firmware TEXT NOT NULL,
            city TEXT NOT NULL DEFAULT 'Dhaka', latitude REAL NOT NULL DEFAULT 23.8103,
            longitude REAL NOT NULL DEFAULT 90.4125, timezone TEXT NOT NULL DEFAULT 'Asia/Dhaka'
        )""")


init_db()


def admin(credentials: HTTPBasicCredentials = Depends(security)):
    user_ok = secrets.compare_digest(credentials.username.encode(), b"admin")
    pass_ok = secrets.compare_digest(credentials.password.encode(), ADMIN_PASSWORD.encode())
    if not (user_ok and pass_ok):
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid dashboard credentials",
                            headers={"WWW-Authenticate": "Basic"})
    return True


def get_device(device_id: str):
    with db() as con:
        return con.execute("SELECT * FROM devices WHERE id=?", (device_id,)).fetchone()


def device_auth(x_device_id: str | None = Header(None), x_device_token: str | None = Header(None)):
    if not x_device_id or not x_device_token:
        raise HTTPException(401, "Missing device credentials")
    row = get_device(x_device_id)
    if row is None or not secrets.compare_digest(row["token_hash"], digest(x_device_token)):
        raise HTTPException(401, "Invalid device credentials")
    return row


def must_be_paired(row):
    if not row["paired"]:
        raise HTTPException(403, "Pair device in dashboard first")


def new_code() -> str:
    return str(secrets.randbelow(900000) + 100000)


class BootstrapBody(BaseModel):
    device_id: str = Field(pattern=r"^[0-9A-Fa-f:]{12,17}$")
    firmware: str = Field(default="0.1.0", max_length=32)


class PairBody(BaseModel):
    code: str = Field(pattern=r"^\d{6}$")
    name: str = Field(default="My ESP32", min_length=1, max_length=50)


class SettingsBody(BaseModel):
    name: str = Field(min_length=1, max_length=50)
    city: str = Field(min_length=1, max_length=80)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    timezone: str = Field(default="Asia/Dhaka", max_length=64)


class AskBody(BaseModel):
    text: str = Field(min_length=1, max_length=500)
    device_id: str | None = None


@app.get("/")
def dashboard(_: bool = Depends(admin)):
    return FileResponse(ROOT / "static" / "index.html")


@app.get("/dashboard.css")
def css():
    return FileResponse(ROOT / "static" / "dashboard.css", media_type="text/css")


@app.get("/dashboard.js")
def js():
    return FileResponse(ROOT / "static" / "dashboard.js", media_type="application/javascript")


@app.get("/api/health")
def health():
    return {"status": "ok", "service": "MyVoice OS", "version": "0.1.0"}


@app.post("/api/device/bootstrap")
def bootstrap(body: BootstrapBody, x_enrollment_key: str | None = Header(None)):
    if not x_enrollment_key or not secrets.compare_digest(x_enrollment_key, ENROLLMENT_KEY):
        raise HTTPException(401, "Invalid enrollment key")
    device_id = body.device_id.upper()
    row = get_device(device_id)
    if row and row["paired"]:
        raise HTTPException(409, "Device is already paired. Use existing token or admin reset procedure.")
    code = new_code()
    token = secrets.token_urlsafe(32)
    with db() as con:
        con.execute("""INSERT INTO devices
            (id, name, token_hash, pair_hash, pair_expires, created_at, last_seen, firmware)
            VALUES (?,?,?,?,?,?,?,?)
            ON CONFLICT(id) DO UPDATE SET token_hash=excluded.token_hash,
            pair_hash=excluded.pair_hash, pair_expires=excluded.pair_expires,
            last_seen=excluded.last_seen, firmware=excluded.firmware""",
            (device_id, "My ESP32", digest(token), code_digest(code),
             (utc_now() + PAIR_DURATION).isoformat(), utc_now().isoformat(),
             utc_now().isoformat(), body.firmware))
    return {"token": token, "pair_code": code, "expires_in_seconds": 600, "paired": False}


@app.get("/api/device/status")
def device_status(row=Depends(device_auth)):
    code = None
    if not row["paired"] and (not row["pair_expires"] or datetime.fromisoformat(row["pair_expires"]) < utc_now()):
        code = new_code()
        with db() as con:
            con.execute("UPDATE devices SET pair_hash=?, pair_expires=? WHERE id=?",
                        (code_digest(code), (utc_now() + PAIR_DURATION).isoformat(), row["id"]))
    return {"paired": bool(row["paired"]), "name": row["name"], "pair_code": code,
            "city": row["city"], "timezone": row["timezone"]}


@app.post("/api/device/heartbeat")
def device_heartbeat(row=Depends(device_auth)):
    must_be_paired(row)
    with db() as con:
        con.execute("UPDATE devices SET last_seen=? WHERE id=?", (utc_now().isoformat(), row["id"]))
    return {"ok": True, "name": row["name"], "server_utc": utc_now().isoformat()}


@app.get("/api/admin/devices")
def devices(_: bool = Depends(admin)):
    with db() as con:
        rows = con.execute("SELECT id,name,paired,created_at,last_seen,firmware,city,latitude,longitude,timezone FROM devices ORDER BY created_at DESC").fetchall()
    return {"devices": [dict(r) for r in rows]}


@app.post("/api/admin/claim")
def claim(body: PairBody, _: bool = Depends(admin)):
    with db() as con:
        row = con.execute("SELECT id,pair_expires FROM devices WHERE paired=0 AND pair_hash=?",
                          (code_digest(body.code),)).fetchone()
        if row is None or not row["pair_expires"] or datetime.fromisoformat(row["pair_expires"]) < utc_now():
            raise HTTPException(404, "Invalid or expired pairing code")
        con.execute("UPDATE devices SET paired=1, name=?, pair_hash=NULL, pair_expires=NULL WHERE id=?",
                    (body.name, row["id"]))
    return {"paired": True, "device_id": row["id"], "name": body.name}


@app.post("/api/admin/devices/{device_id}/settings")
def update_settings(device_id: str, body: SettingsBody, _: bool = Depends(admin)):
    try:
        ZoneInfo(body.timezone)
    except (ZoneInfoNotFoundError, ValueError):
        raise HTTPException(422, "Invalid IANA timezone, e.g. Asia/Dhaka")
    with db() as con:
        c = con.execute("UPDATE devices SET name=?,city=?,latitude=?,longitude=?,timezone=? WHERE id=? AND paired=1",
                        (body.name,body.city,body.latitude,body.longitude,body.timezone,device_id))
        if c.rowcount == 0:
            raise HTTPException(404, "Paired device not found")
    return {"ok": True}


WEATHER_WORDS = ("weather", "temperature", "forecast", "আবহাও", "তাপমাত্রা")
TIME_WORDS = ("time", "clock", "what's the date", "date today", "কয়টা", "কটা", "সময়", "সময়", "তারিখ")
SEARCH_PREFIX = re.compile(r"^(?:please\s+)?(?:search(?:\s+(?:for|the web for))?|look up|find online|সার্চ(?:\s+করো)?|খুঁজে দেখো)\s*[:：]?\s*", re.I)


def condition(code: int) -> str:
    if code == 0: return "clear skies"
    if code in (1,2,3): return "partly cloudy"
    if code in (45,48): return "foggy"
    if 51 <= code <= 67: return "rain or drizzle"
    if 71 <= code <= 77: return "snowy"
    if 80 <= code <= 82: return "rain showers"
    if code in (95,96,99): return "thunderstorms"
    return "variable conditions"


async def fetch_weather(row) -> dict:
    url = "https://api.open-meteo.com/v1/forecast"
    params = {"latitude": row["latitude"], "longitude": row["longitude"],
              "current": "temperature_2m,weather_code,wind_speed_10m"}
    async with httpx.AsyncClient(timeout=12) as client:
        r = await client.get(url, params=params)
        r.raise_for_status()
        d = r.json()["current"]
    return {"city": row["city"], "temperature_c": d["temperature_2m"],
            "conditions": condition(int(d["weather_code"])), "wind_kmh": d["wind_speed_10m"]}


def fallback_profile():
    return {"city": "Dhaka", "latitude": 23.8103, "longitude": 90.4125, "timezone": "Asia/Dhaka"}


async def search_brave(query: str) -> str:
    if not BRAVE_SEARCH_API_KEY:
        return "Web search is not yet configured. Add BRAVE_SEARCH_API_KEY to the server environment."
    async with httpx.AsyncClient(timeout=15) as client:
        response = await client.get("https://api.search.brave.com/res/v1/web/search",
                                    headers={"X-Subscription-Token": BRAVE_SEARCH_API_KEY, "Accept": "application/json"},
                                    params={"q": query, "count": 3})
        response.raise_for_status()
        hits = response.json().get("web", {}).get("results", [])[:3]
    if not hits:
        return "I couldn't find search results for that."
    parts = [f"{h.get('title','Result')}: {h.get('description','')}" for h in hits]
    return "Search results: " + " ".join(parts)[:850]


async def ask_llm(prompt: str) -> str:
    if not OPENAI_API_KEY:
        return "General AI questions require OPENAI_API_KEY. Clock and weather commands work without it."
    async with httpx.AsyncClient(timeout=30) as client:
        response = await client.post("https://api.openai.com/v1/chat/completions",
                                     headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
                                     json={"model": AI_MODEL, "messages": [
                                         {"role": "system", "content": "You are a concise, friendly voice assistant. Respond in the user's language. Keep responses under 70 words. Do not claim to have live web access."},
                                         {"role": "user", "content": prompt}], "max_completion_tokens": 180})
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"] or "I don't have an answer yet."


async def answer_question(question: str, profile) -> str:
    q = question.lower().strip()
    try:
        if any(k in q for k in WEATHER_WORDS):
            w = await fetch_weather(profile)
            return f"In {w['city']}, it's {w['temperature_c']} degrees Celsius with {w['conditions']}. Wind is {w['wind_kmh']} kilometers per hour."
        if any(k in q for k in TIME_WORDS):
            now = datetime.now(ZoneInfo(profile["timezone"]))
            return f"In {profile['city']}, it is {now.strftime('%I:%M %p')} on {now.strftime('%A, %B %d, %Y')}."
        m = SEARCH_PREFIX.match(question.strip())
        if m:
            search_query = question.strip()[m.end():].strip()
            return await search_brave(search_query) if search_query else "Please say what you want me to search for."
        return await ask_llm(question)
    except (httpx.HTTPError, KeyError, ValueError) as e:
        return f"The online service is temporarily unavailable ({type(e).__name__}). Please try again."


@app.post("/api/admin/ask")
async def ask_admin(body: AskBody, _: bool = Depends(admin)):
    profile = get_device(body.device_id) if body.device_id else None
    return {"answer": await answer_question(body.text, profile or fallback_profile())}


@app.get("/api/device/weather")
async def weather_device(row=Depends(device_auth)):
    must_be_paired(row)
    try:
        return await fetch_weather(row)
    except (httpx.HTTPError, KeyError, ValueError):
        raise HTTPException(503, "Weather service temporarily unavailable")


@app.get("/api/device/time")
def time_device(row=Depends(device_auth)):
    must_be_paired(row)
    return {"local_time": datetime.now(ZoneInfo(row["timezone"])).isoformat(),
            "timezone": row["timezone"]}


async def transcribe_wav(data: bytes) -> str:
    async with httpx.AsyncClient(timeout=60) as client:
        result = await client.post("https://api.openai.com/v1/audio/transcriptions",
                                   headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
                                   files={"file": ("recording.wav", data, "audio/wav")},
                                   data={"model": "gpt-4o-mini-transcribe"})
        result.raise_for_status()
        return result.json().get("text", "")


async def synthesize_wav(text: str) -> bytes:
    async with httpx.AsyncClient(timeout=65) as client:
        r = await client.post("https://api.openai.com/v1/audio/speech",
                              headers={"Authorization": f"Bearer {OPENAI_API_KEY}"},
                              json={"model": "tts-1", "voice": "alloy",
                                    "input": text[:1400], "response_format": "wav"})
        r.raise_for_status()
        return r.content


@app.post("/api/device/voice")
async def voice_device(request: Request, row=Depends(device_auth)):
    must_be_paired(row)
    if not OPENAI_API_KEY:
        raise HTTPException(503, "Set OPENAI_API_KEY for voice transcription and spoken playback")
    if request.headers.get("content-type", "").split(";")[0].lower() != "audio/wav":
        raise HTTPException(415, "Expected audio/wav")
    if int(request.headers.get("content-length", "0") or "0") > MAX_WAV_BYTES:
        raise HTTPException(413, "Recording too large")
    audio = await request.body()
    if not (44 <= len(audio) <= MAX_WAV_BYTES) or audio[:4] != b"RIFF" or audio[8:12] != b"WAVE":
        raise HTTPException(400, "Invalid or oversized WAV")
    try:
        question = await transcribe_wav(audio)
        if not question.strip():
            question = "I couldn't hear anything clearly."
            answer = "I couldn't hear you clearly. Please try again."
        else:
            answer = await answer_question(question, row)
        speech = await synthesize_wav(answer)
    except httpx.HTTPError:
        raise HTTPException(502, "Cloud audio service failed; check API key, quota and connectivity")
    with db() as con:
        con.execute("UPDATE devices SET last_seen=? WHERE id=?", (utc_now().isoformat(), row["id"]))
    # Text is available in headers (shortened to keep header values printable/ASCII).
    return Response(content=speech, media_type="audio/wav",
                    headers={"X-Transcript-Available": "true", "Cache-Control": "no-store"})
